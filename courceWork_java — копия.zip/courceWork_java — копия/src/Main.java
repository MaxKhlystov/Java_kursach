import dao.*;
import dao.impl.*;
import service.*;
import ui.MainFrame;
import util.DatabaseConnection;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        try {
            // Устанавливаем соединение с базой данных
            DatabaseConnection dbConnection = new DatabaseConnection();
            Connection connection = dbConnection.getConnection();

            // Создаём DAO-объекты
            StudentDAO studentDAO = new StudentDAOImpl(connection);
            ConsultationDAO consultationDAO = new ConsultationDAOImpl(connection, studentDAO);
            CorrectionWorkDAO correctionWorkDAO = new CorrectionWorkDAOImpl(connection, studentDAO);
            DiagnosticRecordDAO diagnosticRecordDAO = new DiagnosticRecordDAOImpl(connection);
            PreventiveActivityDAO preventiveActivityDAO = new PreventiveActivityDAOImpl(connection);
            JournalDAO journalDAO = new JournalDAOImpl(connection);

            JournalService journalService = new JournalServiceImpl(
                    studentDAO,
                    consultationDAO,
                    preventiveActivityDAO,
                    diagnosticRecordDAO,
                    correctionWorkDAO,
                    journalDAO
            );

            // Запускаем UI в EDT
            SwingUtilities.invokeLater(() -> {
                MainFrame mainFrame = new MainFrame(journalService);
                mainFrame.setVisible(true);
            });

            // Закрытие соединения при завершении
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }));

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                    "Ошибка подключения к базе данных: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
