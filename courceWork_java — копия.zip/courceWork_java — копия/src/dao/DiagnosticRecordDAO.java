package dao;

import model.DiagnosticRecord;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public interface DiagnosticRecordDAO {
    void addDiagnosticRecord(DiagnosticRecord d);
    void updateDiagnosticRecord(DiagnosticRecord d);
    void deleteDiagnosticRecord(int id);
    DiagnosticRecord getDiagnosticRecordById(int id);
    List<DiagnosticRecord> getAllDiagnosticRecords();
    List<DiagnosticRecord> getByStudentId(int studentId);
    List<DiagnosticRecord> getByDate(Date date);
    List<DiagnosticRecord> getByJournalId(long journalId) throws SQLException;
}
