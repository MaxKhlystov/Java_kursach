package dao;

import model.CorrectionWork;
import java.util.List;

public interface CorrectionWorkDAO {
    void addCorrectionWork(CorrectionWork correctionWork);
    void updateCorrectionWork(CorrectionWork correctionWork);
    void deleteCorrectionWork(int id);
    CorrectionWork getCorrectionWorkById(int id);
    List<CorrectionWork> getAllCorrectionWorks();
    List<CorrectionWork> getByStudentId(int studentId);
    List<CorrectionWork> getByJournalId(int journalId);

}
