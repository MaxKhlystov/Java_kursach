package dao;

import model.Consultation;
import java.sql.Date;
import java.util.List;

public interface ConsultationDAO {
    void addConsultation(Consultation consultation);
    void updateConsultation(Consultation consultation);
    void deleteConsultation(int id);
    Consultation getConsultationById(int id);
    List<Consultation> getAllConsultations();
    List<Consultation> getByStudentId(int studentId);
    List<Consultation> getByDate(Date date);
    List<Consultation> getByJournalId(int journalId);
}