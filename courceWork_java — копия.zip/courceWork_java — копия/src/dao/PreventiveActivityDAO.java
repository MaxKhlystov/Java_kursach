package dao;

import model.PreventiveActivity;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public interface PreventiveActivityDAO {
    void addPreventiveActivity(PreventiveActivity activity, long journalId) throws SQLException;
    void updatePreventiveActivity(PreventiveActivity activity) throws SQLException;
    void deletePreventiveActivity(int id) throws SQLException;
    PreventiveActivity getPreventiveActivityById(int id) throws SQLException;
    List<PreventiveActivity> getAllPreventiveActivities() throws SQLException;
    List<PreventiveActivity> getByDate(Date date) throws SQLException;
    List<PreventiveActivity> getByJournalId(long journalId) throws SQLException;
}
