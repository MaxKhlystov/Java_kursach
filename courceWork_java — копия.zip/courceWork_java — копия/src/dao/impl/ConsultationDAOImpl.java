package dao.impl;

import dao.ConsultationDAO;
import dao.StudentDAO;
import model.Consultation;
import model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConsultationDAOImpl implements ConsultationDAO {
    private final Connection connection;
    private final StudentDAO studentDAO;

    public ConsultationDAOImpl(Connection connection, StudentDAO studentDAO) {
        this.connection = connection;
        this.studentDAO = studentDAO;
    }

    @Override
    public void addConsultation(Consultation c) {
        String sql = "INSERT INTO consultations (journal_id, date, student_id, reason, content, result) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, c.getJournalId());
            stmt.setDate(2, c.getDate());
            stmt.setInt(3, c.getStudent().getId());
            stmt.setString(4, c.getReason());
            stmt.setString(5, c.getContent());
            stmt.setString(6, c.getResult());
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    c.setId(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateConsultation(Consultation c) {
        String sql = "UPDATE consultations SET journal_id = ?, date = ?, student_id = ?, reason = ?, content = ?, result = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, c.getJournalId());
            stmt.setDate(2, c.getDate());
            stmt.setInt(3, c.getStudent().getId());
            stmt.setString(4, c.getReason());
            stmt.setString(5, c.getContent());
            stmt.setString(6, c.getResult());
            stmt.setInt(7, c.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteConsultation(int id) {
        String sql = "DELETE FROM consultations WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Consultation getConsultationById(int id) {
        String sql = "SELECT * FROM consultations WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Student student = studentDAO.getStudentById(rs.getInt("student_id"));
                    return extractConsultation(rs, student);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Consultation> getAllConsultations() {
        List<Consultation> list = new ArrayList<>();
        String sql = "SELECT * FROM consultations";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Student student = studentDAO.getStudentById(rs.getInt("student_id"));
                list.add(extractConsultation(rs, student));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Consultation> getByStudentId(int studentId) {
        List<Consultation> list = new ArrayList<>();
        String sql = "SELECT * FROM consultations WHERE student_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Student student = studentDAO.getStudentById(studentId);
                    list.add(extractConsultation(rs, student));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Consultation> getByDate(Date date) {
        List<Consultation> list = new ArrayList<>();
        String sql = "SELECT * FROM consultations WHERE date = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, date);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Student student = studentDAO.getStudentById(rs.getInt("student_id"));
                    list.add(extractConsultation(rs, student));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Consultation> getByJournalId(int journalId) {
        List<Consultation> list = new ArrayList<>();
        String sql = "SELECT * FROM consultations WHERE journal_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, journalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Student student = studentDAO.getStudentById(rs.getInt("student_id"));
                    list.add(extractConsultation(rs, student));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    private Consultation extractConsultation(ResultSet rs, Student student) throws SQLException {
        return new Consultation(
                rs.getInt("id"),
                rs.getInt("journal_id"),
                rs.getDate("date"),
                student,
                rs.getString("reason"),
                rs.getString("content"),
                rs.getString("result")
        );
    }
}
