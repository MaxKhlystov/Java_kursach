package dao.impl;

import dao.CorrectionWorkDAO;
import dao.StudentDAO;
import model.CorrectionWork;
import model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CorrectionWorkDAOImpl implements CorrectionWorkDAO {
    private final Connection connection;
    private final StudentDAO studentDAO;

    public CorrectionWorkDAOImpl(Connection connection, StudentDAO studentDAO) {
        this.connection = connection;
        this.studentDAO = studentDAO;
    }

    @Override
    public void addCorrectionWork(CorrectionWork cw) {
        String sql = "INSERT INTO correction_work (date, type, student_id, parent_name, class_name, " +
                "topic, solution, recommendations, result, journal_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setDate(1, cw.getDate());
            stmt.setString(2, cw.getType());
            stmt.setInt(3, cw.getStudent().getId());
            stmt.setString(4, cw.getParentName());
            stmt.setString(5, cw.getClassName());
            stmt.setString(6, cw.getTopic());
            stmt.setString(7, cw.getSolution());
            stmt.setString(8, cw.getRecommendations());
            stmt.setString(9, cw.getResult());
            stmt.setInt(10, cw.getJournalId());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    cw.setId(generatedKeys.getInt(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateCorrectionWork(CorrectionWork cw) {
        String sql = "UPDATE correction_work SET date = ?, type = ?, student_id = ?, parent_name = ?, " +
                "class_name = ?, topic = ?, solution = ?, recommendations = ?, result = ?, journal_id = ? WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, cw.getDate());
            stmt.setString(2, cw.getType());
            stmt.setString(3, cw.getClassName());
            stmt.setInt(4, cw.getStudent().getId());
            stmt.setString(5, cw.getParentName());

            stmt.setString(6, cw.getTopic());
            stmt.setString(7, cw.getSolution());
            stmt.setString(8, cw.getRecommendations());
            stmt.setString(9, cw.getResult());
            stmt.setInt(10, cw.getJournalId());
            stmt.setInt(11, cw.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteCorrectionWork(int id) {
        String sql = "DELETE FROM correction_work WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public CorrectionWork getCorrectionWorkById(int id) {
        String sql = "SELECT * FROM correction_work WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractCorrectionWorkFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<CorrectionWork> getAllCorrectionWorks() {
        List<CorrectionWork> works = new ArrayList<>();
        String sql = "SELECT * FROM correction_work";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                works.add(extractCorrectionWorkFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return works;
    }

    @Override
    public List<CorrectionWork> getByStudentId(int studentId) {
        List<CorrectionWork> works = new ArrayList<>();
        String sql = "SELECT * FROM correction_work WHERE student_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    works.add(extractCorrectionWorkFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return works;
    }

    private CorrectionWork extractCorrectionWorkFromResultSet(ResultSet rs) throws SQLException {
        Student student = studentDAO.getStudentById(rs.getInt("student_id"));
        return new CorrectionWork(
                rs.getInt("id"),
                rs.getDate("date"),
                rs.getString("type"),
                student,
                rs.getString("parent_name"),
                rs.getString("class_name"),
                rs.getString("topic"),
                rs.getString("solution"),
                rs.getString("recommendations"),
                rs.getString("result"),
                rs.getInt("journal_id")
        );
    }

    @Override
    public List<CorrectionWork> getByJournalId(int journalId) {
        List<CorrectionWork> works = new ArrayList<>();
        String sql = "SELECT * FROM correction_work WHERE journal_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, journalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    works.add(extractCorrectionWorkFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return works;
    }
}