package dao.impl;

import dao.JournalDAO;
import model.Journal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JournalDAOImpl implements JournalDAO {
    private final Connection connection;

    public JournalDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void addJournal(Journal journal) throws SQLException {
        String sql = "INSERT INTO journals (name, type) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, journal.getName());
            stmt.setString(2, journal.getType());
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    journal.setId(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public void deleteJournal(int journalId) throws SQLException {
        String sql = "DELETE FROM journals WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, journalId);
            stmt.executeUpdate();
        }
    }

    @Override
    public void updateJournal(Journal journal) throws SQLException {
        String sql = "UPDATE journals SET name = ?, type = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, journal.getName());
            stmt.setString(2, journal.getType());
            stmt.setInt(3, journal.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public List<Journal> getAllJournals() throws SQLException {
        List<Journal> list = new ArrayList<>();
        String sql = "SELECT * FROM journals ORDER BY created_at";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(extractJournal(rs));
            }
        }
        return list;
    }

    @Override
    public List<Journal> getJournalsByType(String type) throws SQLException {
        List<Journal> list = new ArrayList<>();
        String sql = "SELECT * FROM journals WHERE type = ? ORDER BY created_at";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, type);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(extractJournal(rs));
                }
            }
        }
        return list;
    }

    @Override
    public Journal getJournalById(int id) throws SQLException {
        String sql = "SELECT * FROM journals WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractJournal(rs);
                }
            }
        }
        return null;
    }

    private Journal extractJournal(ResultSet rs) throws SQLException {
        return new Journal(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("type"),
                rs.getTimestamp("created_at")
        );
    }
}
