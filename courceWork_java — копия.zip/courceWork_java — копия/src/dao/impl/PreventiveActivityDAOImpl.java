package dao.impl;

import dao.PreventiveActivityDAO;
import model.PreventiveActivity;
import util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PreventiveActivityDAOImpl implements PreventiveActivityDAO {
    private final Connection connection;

    public PreventiveActivityDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void addPreventiveActivity(PreventiveActivity activity, long journalId) throws SQLException {
        String sql = "INSERT INTO preventive_activities (journal_id, date, class_name, topic, content, participants_count, result) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, journalId);
            stmt.setDate(2, activity.getDate());
            stmt.setString(3, activity.getClassName());
            stmt.setString(4, activity.getTopic());
            stmt.setString(5, activity.getContent());
            stmt.setInt(6, activity.getParticipantsCount());
            stmt.setString(7, activity.getResult());
            stmt.executeUpdate();
        }
    }

    @Override
    public void updatePreventiveActivity(PreventiveActivity activity) throws SQLException {
        String sql = "UPDATE preventive_activities SET date = ?, class_name = ?, topic = ?, content = ?, participants_count = ?, result = ? " +
                "WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, activity.getDate());
            stmt.setString(2, activity.getClassName());
            stmt.setString(3, activity.getTopic());
            stmt.setString(4, activity.getContent());
            stmt.setInt(5, activity.getParticipantsCount());
            stmt.setString(6, activity.getResult());
            stmt.setInt(7, activity.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void deletePreventiveActivity(int id) throws SQLException {
        String sql = "DELETE FROM preventive_activities WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    @Override
    public PreventiveActivity getPreventiveActivityById(int id) throws SQLException {
        String sql = "SELECT * FROM preventive_activities WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapRow(rs);
            }
        }
        return null;
    }

    @Override
    public List<PreventiveActivity> getAllPreventiveActivities() throws SQLException {
        String sql = "SELECT * FROM preventive_activities";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            List<PreventiveActivity> list = new ArrayList<>();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
            return list;
        }
    }

    @Override
    public List<PreventiveActivity> getByDate(Date date) throws SQLException {
        String sql = "SELECT * FROM preventive_activities WHERE date = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, date);
            ResultSet rs = stmt.executeQuery();

            List<PreventiveActivity> list = new ArrayList<>();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
            return list;
        }
    }

    @Override
    public List<PreventiveActivity> getByJournalId(long journalId) throws SQLException {
        String sql = "SELECT * FROM preventive_activities WHERE journal_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, journalId);
            ResultSet rs = stmt.executeQuery();

            List<PreventiveActivity> list = new ArrayList<>();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
            return list;
        }
    }

    private PreventiveActivity mapRow(ResultSet rs) throws SQLException {
        return new PreventiveActivity(
                rs.getInt("id"),
                rs.getInt("journal_id"), // journalId идёт вторым
                rs.getDate("date"),
                rs.getString("class_name"),
                rs.getString("topic"),
                rs.getString("content"),
                rs.getInt("participants_count"),
                rs.getString("result")
        );
    }
}
