package dao.impl;

import dao.DiagnosticRecordDAO;
import model.DiagnosticRecord;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DiagnosticRecordDAOImpl implements DiagnosticRecordDAO {
    private final Connection connection;

    public DiagnosticRecordDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void addDiagnosticRecord(DiagnosticRecord d) {
        String sql = "INSERT INTO diagnostics (date, form, participants, participants_count, topic, content, result, journal_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, d.getDate());
            stmt.setString(2, d.getForm());
            stmt.setString(3, d.getParticipants());
            stmt.setInt(4, d.getParticipantsCount());
            stmt.setString(5, d.getTopic());
            stmt.setString(6, d.getContent());
            stmt.setString(7, d.getResult());
            stmt.setInt(8, d.getJournalId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateDiagnosticRecord(DiagnosticRecord d) {
        String sql = "UPDATE diagnostics SET date = ?, form = ?, participants = ?, participants_count = ?, topic = ?, " +
                "content = ?, result = ?, journal_id = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, d.getDate());
            stmt.setString(2, d.getForm());
            stmt.setString(3, d.getParticipants());
            stmt.setInt(4, d.getParticipantsCount());
            stmt.setString(5, d.getTopic());
            stmt.setString(6, d.getContent());
            stmt.setString(7, d.getResult());
            stmt.setInt(8, d.getJournalId());
            stmt.setInt(9, d.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteDiagnosticRecord(int id) {
        String sql = "DELETE FROM diagnostics WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public DiagnosticRecord getDiagnosticRecordById(int id) {
        String sql = "SELECT * FROM diagnostics WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return extractDiagnosticRecordFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<DiagnosticRecord> getAllDiagnosticRecords() {
        List<DiagnosticRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM diagnostics";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                records.add(extractDiagnosticRecordFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public List<DiagnosticRecord> getByStudentId(int studentId) {
        throw new UnsupportedOperationException("This method is not supported unless student_id exists in diagnostics table.");
    }

    @Override
    public List<DiagnosticRecord> getByDate(Date date) {
        List<DiagnosticRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM diagnostics WHERE date = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, date);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    records.add(extractDiagnosticRecordFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    @Override
    public List<DiagnosticRecord> getByJournalId(long journalId) {
        List<DiagnosticRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM diagnostics WHERE journal_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, journalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    records.add(extractDiagnosticRecordFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return records;
    }

    private DiagnosticRecord extractDiagnosticRecordFromResultSet(ResultSet rs) throws SQLException {
        return new DiagnosticRecord(
                rs.getInt("id"),
                rs.getDate("date"),
                rs.getString("form"),
                rs.getString("participants"),
                rs.getInt("participants_count"),
                rs.getString("topic"),
                rs.getString("content"),
                rs.getString("result"),
                rs.getInt("journal_id")
        );
    }
}
