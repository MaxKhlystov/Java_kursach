package dao;

import model.Journal;

import java.sql.SQLException;
import java.util.List;

public interface JournalDAO {
    void addJournal(Journal journal) throws SQLException;
    void deleteJournal(int journalId) throws SQLException;
    List<Journal> getAllJournals() throws SQLException;
    List<Journal> getJournalsByType(String type) throws SQLException;
    Journal getJournalById(int id) throws SQLException;
    void updateJournal(Journal journal) throws SQLException;

}
