package ui.dialogs;

import model.DiagnosticRecord;
import model.Journal;
import service.JournalService;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class DiagnosticDialog extends JDialog {
    private final JournalService service;
    private final Journal journal;
    private DiagnosticRecord record;
    private boolean saved = false;

    private JTextField dateField;
    private JTextField formField;
    private JTextField participantsField;
    private JTextField participantsCountField;
    private JTextField topicField;
    private JTextArea contentArea;
    private JTextArea resultArea;

    public DiagnosticDialog(Window owner, JournalService service, Journal journal, DiagnosticRecord record) {
        super(owner, "Диагностическая работа", ModalityType.APPLICATION_MODAL);
        this.service = service;
        this.journal = journal;
        this.record = record;

        initUI();
        setSize(550, 450);
        setLocationRelativeTo(owner);
    }

    private void initUI() {
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Ширина метки (левая колонка)
        GridBagConstraints labelGbc = (GridBagConstraints) gbc.clone();
        labelGbc.weightx = 0;

        // Ширина поля (правая колонка)
        GridBagConstraints fieldGbc = (GridBagConstraints) gbc.clone();
        fieldGbc.gridx = 1;
        fieldGbc.weightx = 1.0;

        // Дата
        form.add(new JLabel("Дата (дд.мм.гггг):"), labelGbc);
        dateField = new JTextField();
        form.add(dateField, fieldGbc);

        // Форма проведения
        gbc.gridy++;
        labelGbc.gridy = gbc.gridy;
        fieldGbc.gridy = gbc.gridy;
        form.add(new JLabel("Форма проведения:"), labelGbc);
        formField = new JTextField();
        form.add(formField, fieldGbc);

        // С кем проводится
        gbc.gridy++;
        labelGbc.gridy = gbc.gridy;
        fieldGbc.gridy = gbc.gridy;
        form.add(new JLabel("С кем проводится:"), labelGbc);
        participantsField = new JTextField();
        form.add(participantsField, fieldGbc);

        // Количество участников
        gbc.gridy++;
        labelGbc.gridy = gbc.gridy;
        fieldGbc.gridy = gbc.gridy;
        form.add(new JLabel("Количество участников:"), labelGbc);
        participantsCountField = new JTextField();
        form.add(participantsCountField, fieldGbc);

        // Тематика
        gbc.gridy++;
        labelGbc.gridy = gbc.gridy;
        fieldGbc.gridy = gbc.gridy;
        form.add(new JLabel("Тематика:"), labelGbc);
        topicField = new JTextField();
        form.add(topicField, fieldGbc);

        // Содержание
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        form.add(new JLabel("Содержание:"), gbc);
        gbc.gridy++;
        contentArea = new JTextArea(3, 20);
        JScrollPane contentScroll = new JScrollPane(contentArea);
        contentScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        form.add(contentScroll, gbc);

        // Результат
        gbc.gridy++;
        form.add(new JLabel("Результат:"), gbc);
        gbc.gridy++;
        resultArea = new JTextArea(3, 20);
        JScrollPane resultScroll = new JScrollPane(resultArea);
        resultScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        form.add(resultScroll, gbc);

        add(form, BorderLayout.CENTER);

        // Кнопки
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton saveButton = new JButton("Сохранить");
        JButton cancelButton = new JButton("Отмена");

        saveButton.addActionListener(e -> onSave());
        cancelButton.addActionListener(e -> dispose());

        buttons.add(saveButton);
        buttons.add(cancelButton);
        add(buttons, BorderLayout.SOUTH);

        if (record != null) {
            fillFields();
        }
    }


    private void fillFields() {
        dateField.setText(record.getDate().toString());
        formField.setText(record.getForm());
        participantsField.setText(record.getParticipants());
        participantsCountField.setText(String.valueOf(record.getParticipantsCount()));
        topicField.setText(record.getTopic());
        contentArea.setText(record.getContent());
        resultArea.setText(record.getResult());
    }

    private void onSave() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
            Date date = new Date(sdf.parse(dateField.getText().trim()).getTime());

            String form = formField.getText().trim();
            String participants = participantsField.getText().trim();

            // Проверка что количество участников - число
            int count;
            try {
                count = Integer.parseInt(participantsCountField.getText().trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Количество участников должно быть числом",
                        "Ошибка", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String topic = topicField.getText().trim();
            String content = contentArea.getText().trim();
            String result = resultArea.getText().trim();

            if (record == null) {
                record = new DiagnosticRecord(0, date, form, participants, count, topic, content, result, journal.getId());
            } else {
                record.setDate(date);
                record.setForm(form);
                record.setParticipants(participants);
                record.setParticipantsCount(count);
                record.setTopic(topic);
                record.setContent(content);
                record.setResult(result);
                record.setJournalId(journal.getId());
            }

            saved = true;
            dispose();
        } catch (java.text.ParseException e) {
            JOptionPane.showMessageDialog(this, "Неверный формат даты. Используйте дд.мм.гггг",
                    "Ошибка", JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ошибка при сохранении: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSaved() {
        return saved;
    }

    public DiagnosticRecord getRecord() {
        return record;
    }
}
