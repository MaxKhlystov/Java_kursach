package ui.dialogs;

import model.Consultation;
import model.Journal;
import model.Student;
import service.JournalService;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

public class ConsultationDialog extends JDialog {
    private final JournalService service;
    private final Journal journal;
    private final Consultation consultation;
    private boolean saved = false;

    private JComboBox<Student> studentBox;
    private JTextField dateField;
    private JTextField reasonField;
    private JTextField contentField;
    private JTextField resultField;

    public ConsultationDialog(Window owner, JournalService service, Journal journal, Consultation consultation) {
        super(owner, "Консультация", ModalityType.APPLICATION_MODAL);
        this.service = service;
        this.journal = journal;
        this.consultation = consultation;

        initUI();
        setSize(400, 300);
        setLocationRelativeTo(owner);
    }

    private void initUI() {
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Ученик — подпись
        form.add(new JLabel("Ученик:"), gbc);

        // Ученик — выпадающий список + кнопка
        studentBox = new JComboBox<>();
        studentBox.addItem(null);
        for (Student student : service.getAllStudents()) {
            studentBox.addItem(student);
        }
        studentBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Student student) {
                    setText(student.getLastName() + " " + student.getFirstName() + " " + student.getMiddleName());
                } else {
                    setText(""); // для null
                }
                return this;
            }
        });

        JPanel studentPanel = new JPanel(new BorderLayout(5, 0));
        studentPanel.add(studentBox, BorderLayout.CENTER);
        JButton addStudentButton = new JButton("+");
        addStudentButton.setToolTipText("Добавить нового ученика");
        studentPanel.add(addStudentButton, BorderLayout.EAST);
        addStudentButton.addActionListener(e -> {
            AddStudentDialog dialog = new AddStudentDialog((JFrame) SwingUtilities.getWindowAncestor(this));
            dialog.setVisible(true);
            if (dialog.isOkPressed()) {
                Student newStudent = dialog.getStudent();
                service.addStudent(newStudent);
                reloadStudents();
                studentBox.setSelectedItem(newStudent);
            }
        });

        gbc.gridx = 1;
        gbc.gridwidth = 2;
        form.add(studentPanel, gbc);

        // Дата
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Дата (дд.мм.гггг):"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        dateField = new JTextField();
        form.add(dateField, gbc);

        // Причина
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Причина:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        reasonField = new JTextField();
        form.add(reasonField, gbc);

        // Содержание
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Содержание:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        contentField = new JTextField();
        form.add(contentField, gbc);

        // Результат
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Результат:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        resultField = new JTextField();
        form.add(resultField, gbc);

        add(form, BorderLayout.CENTER);

        // Кнопки
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton saveButton = new JButton("Сохранить");
        JButton cancelButton = new JButton("Отмена");

        saveButton.addActionListener(e -> onSave());
        cancelButton.addActionListener(e -> dispose());

        buttons.add(saveButton);
        buttons.add(cancelButton);
        add(buttons, BorderLayout.SOUTH);

        if (consultation != null) {
            fillFields();
        }
    }


    private void reloadStudents() {
        studentBox.removeAllItems();
        studentBox.addItem(null);
        for (Student s : service.getAllStudents()) {
            studentBox.addItem(s);
        }
    }

    private void loadStudents() {
        try {
            List<Student> students = service.getAllStudents();
            DefaultComboBoxModel<Student> model = new DefaultComboBoxModel<>();
            for (Student s : students) {
                model.addElement(s);
            }
            studentBox.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ошибка загрузки учеников: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void fillFields() {
        studentBox.setSelectedItem(consultation.getStudent());
        dateField.setText(consultation.getDate().toString());
        reasonField.setText(consultation.getReason());
        contentField.setText(consultation.getContent());
        resultField.setText(consultation.getResult());
    }

    private void onSave() {
        try {
            Object selected = studentBox.getSelectedItem();
            Student student;

            if (selected instanceof Student) {
                student = (Student) selected;
            } else {
                JOptionPane.showMessageDialog(this, "Выберите ученика из списка или создайте нового.",
                        "Ошибка", JOptionPane.WARNING_MESSAGE);
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
            Date date = new Date(sdf.parse(dateField.getText().trim()).getTime());

            String reason = reasonField.getText().trim();
            String content = contentField.getText().trim();
            String result = resultField.getText().trim();

            if (consultation == null) {
                Consultation newConsultation = new Consultation(
                        0, journal.getId(), date, student, reason, content, result);
                service.addConsultation(newConsultation);
            } else {
                consultation.setStudent(student);
                consultation.setDate(date);
                consultation.setReason(reason);
                consultation.setContent(content);
                consultation.setResult(result);
                service.updateConsultation(consultation);
            }

            saved = true;
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ошибка сохранения: " + ex.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSaved() {
        return saved;
    }
}
