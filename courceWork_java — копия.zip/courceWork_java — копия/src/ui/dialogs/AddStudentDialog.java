package ui.dialogs;

import model.Student;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddStudentDialog extends JDialog {
    private Student student;
    private boolean okPressed = false;

    private JTextField lastNameField;
    private JTextField firstNameField;
    private JTextField middleNameField;
    private JTextField classNameField;

    public AddStudentDialog(JFrame parent) {
        this(parent, new Student());
    }

    public AddStudentDialog(JFrame parent, Student student) {
        super(parent, student.getId() == 0 ? "Добавить ученика" : "Редактировать ученика", true);
        this.student = student;
        initializeUI();
    }

    private void initializeUI() {
        setSize(400, 250);
        setLocationRelativeTo(getParent());

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Last name
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Фамилия:"), gbc);

        gbc.gridx = 1;
        lastNameField = new JTextField(20);
        lastNameField.setText(student.getLastName());
        panel.add(lastNameField, gbc);

        // First name
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Имя:"), gbc);

        gbc.gridx = 1;
        firstNameField = new JTextField(20);
        firstNameField.setText(student.getFirstName());
        panel.add(firstNameField, gbc);

        // Middle name
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Отчество:"), gbc);

        gbc.gridx = 1;
        middleNameField = new JTextField(20);
        middleNameField.setText(student.getMiddleName());
        panel.add(middleNameField, gbc);

        // Class
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Класс:"), gbc);

        gbc.gridx = 1;
        classNameField = new JTextField(20);
        classNameField.setText(student.getClassName());
        panel.add(classNameField, gbc);

        // Buttons
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateInput()) {
                    okPressed = true;
                    setVisible(false);
                }
            }
        });
        buttonPanel.add(okButton);

        JButton cancelButton = new JButton("Отмена");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                okPressed = false;
                setVisible(false);
            }
        });
        buttonPanel.add(cancelButton);

        panel.add(buttonPanel, gbc);

        add(panel);
    }

    private boolean validateInput() {
        if (lastNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Введите фамилию", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (firstNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Введите имя", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (classNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Введите класс", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    public boolean isOkPressed() {
        return okPressed;
    }

    public Student getStudent() {
        student.setLastName(lastNameField.getText().trim());
        student.setFirstName(firstNameField.getText().trim());
        student.setMiddleName(middleNameField.getText().trim());
        student.setClassName(classNameField.getText().trim());
        return student;
    }
}