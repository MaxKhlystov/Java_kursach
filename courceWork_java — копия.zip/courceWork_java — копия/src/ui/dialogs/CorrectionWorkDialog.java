package ui.dialogs;

import model.CorrectionWork;
import model.Journal;
import model.Student;
import service.JournalService;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class CorrectionWorkDialog extends JDialog {
    private final JournalService service;
    private final Journal journal;
    private final CorrectionWork correctionWork;
    private boolean saved = false;

    private JComboBox<Student> studentBox;
    private JTextField dateField;
    private JComboBox<String> typeCombo;
    private JTextField classField;
    private JTextField parentField;
    private JTextField topicField;
    private JTextField solutionField;
    private JTextField recommendationsField;
    private JTextField resultField;

    public CorrectionWorkDialog(Window owner, JournalService service, Journal journal, CorrectionWork correctionWork) {
        super(owner, "Коррекционная работа", ModalityType.APPLICATION_MODAL);
        this.service = service;
        this.journal = journal;
        this.correctionWork = correctionWork;

        initUI();
        setSize(500, 400);
        setLocationRelativeTo(owner);
    }

    private void initUI() {
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(10, 2, 5, 5));
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        form.add(new JLabel("Дата (дд.мм.гггг):"));
        dateField = new JTextField();
        form.add(dateField);

        form.add(new JLabel("Тип работы:"));
        typeCombo = new JComboBox<>(new String[]{"INDIVIDUAL", "GROUP"});
        form.add(typeCombo);

        form.add(new JLabel("Ученик:"));
        JPanel studentPanel = new JPanel(new BorderLayout(5, 0));

        studentBox = new JComboBox<>();
        studentBox.addItem(null);
        for (Student student : service.getAllStudents()) {
            studentBox.addItem(student);
        }
        studentBox.addActionListener(e -> {
            Student selected = (Student) studentBox.getSelectedItem();
            if (selected != null) {
                classField.setText(selected.getClassName()); // <-- добавлено
            } else {
                classField.setText(""); // <-- добавлено
            }
        });

        studentBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Student student) {
                    setText(student.getLastName() + " " + student.getFirstName() + " " + student.getMiddleName());
                } else {
                    setText("");
                }
                return this;
            }
        });

        JButton addStudentButton = new JButton("+");
        addStudentButton.setToolTipText("Добавить нового ученика");
        addStudentButton.addActionListener(e -> {
            AddStudentDialog dialog = new AddStudentDialog((JFrame) SwingUtilities.getWindowAncestor(this));
            dialog.setVisible(true);
            if (dialog.isOkPressed()) {
                Student newStudent = dialog.getStudent();
                service.addStudent(newStudent);
                reloadStudents();
                studentBox.setSelectedItem(newStudent);
            }
        });
        studentPanel.add(studentBox, BorderLayout.CENTER);
        studentPanel.add(addStudentButton, BorderLayout.EAST);
        form.add(studentPanel);

        form.add(new JLabel("Класс:"));
        classField = new JTextField();
        form.add(classField);

        form.add(new JLabel("Родитель:"));
        parentField = new JTextField();
        form.add(parentField);

        form.add(new JLabel("Тематика:"));
        topicField = new JTextField();
        form.add(topicField);

        form.add(new JLabel("Решение:"));
        solutionField = new JTextField();
        form.add(solutionField);

        form.add(new JLabel("Рекомендации:"));
        recommendationsField = new JTextField();
        form.add(recommendationsField);

        form.add(new JLabel("Результат:"));
        resultField = new JTextField();
        form.add(resultField);

        add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton saveButton = new JButton("Сохранить");
        JButton cancelButton = new JButton("Отмена");

        saveButton.addActionListener(e -> onSave());
        cancelButton.addActionListener(e -> dispose());

        buttons.add(saveButton);
        buttons.add(cancelButton);
        add(buttons, BorderLayout.SOUTH);

        if (correctionWork != null) {
            fillFields();
        }
    }

    private void reloadStudents() {
        studentBox.removeAllItems();
        studentBox.addItem(null);
        for (Student s : service.getAllStudents()) {
            studentBox.addItem(s);
        }
    }

    private void fillFields() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        dateField.setText(sdf.format(correctionWork.getDate()));
        typeCombo.setSelectedItem(correctionWork.getType());
        studentBox.setSelectedItem(correctionWork.getStudent());
        parentField.setText(correctionWork.getParentName());
        classField.setText(correctionWork.getClassName());
        topicField.setText(correctionWork.getTopic());
        solutionField.setText(correctionWork.getSolution());
        recommendationsField.setText(correctionWork.getRecommendations());
        resultField.setText(correctionWork.getResult());
    }

    private void onSave() {
        try {
            Object selected = studentBox.getSelectedItem();
            if (!(selected instanceof Student student)) {
                JOptionPane.showMessageDialog(this, "Выберите ученика из списка или создайте нового.",
                        "Ошибка", JOptionPane.WARNING_MESSAGE);
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
            Date date = new Date(sdf.parse(dateField.getText().trim()).getTime());

            String type = (String) typeCombo.getSelectedItem();
            String parentName = parentField.getText().trim();
            String className = classField.getText().trim();
            String topic = topicField.getText().trim();
            String solution = solutionField.getText().trim();
            String recommendations = recommendationsField.getText().trim();
            String result = resultField.getText().trim();

            if (correctionWork == null) {
                CorrectionWork newCW = new CorrectionWork(
                        0, date, type, student, parentName, className,
                        topic, solution, recommendations, result, journal.getId()
                );
                service.addCorrectionWork(newCW);
            } else {
                correctionWork.setDate(date);
                correctionWork.setType(type);
                correctionWork.setStudent(student);
                correctionWork.setParentName(parentName);
                correctionWork.setClassName(className);
                correctionWork.setTopic(topic);
                correctionWork.setSolution(solution);
                correctionWork.setRecommendations(recommendations);
                correctionWork.setResult(result);
                service.updateCorrectionWork(correctionWork);
            }

            saved = true;
            dispose();
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Неверный формат даты. Используйте дд.мм.гггг.",
                    "Ошибка", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ошибка сохранения: " + ex.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSaved() {
        return saved;
    }
}
