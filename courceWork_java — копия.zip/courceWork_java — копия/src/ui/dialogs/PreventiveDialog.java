package ui.dialogs;

import model.Journal;
import model.PreventiveActivity;
import service.JournalService;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class PreventiveDialog extends JDialog {
    private final JournalService service;
    private final Journal journal;
    private final PreventiveActivity existingActivity;
    private boolean saved = false;

    private JTextField dateField;
    private JTextField classNameField;
    private JTextField topicField;
    private JTextArea contentArea;
    private JTextField participantsCountField;
    private JTextArea resultArea;

    public PreventiveDialog(Window owner, JournalService service, Journal journal, PreventiveActivity activity) {
        super(owner, "Профилактическое мероприятие", ModalityType.APPLICATION_MODAL);
        this.service = service;
        this.journal = journal;
        this.existingActivity = activity;

        initUI();
        setSize(450, 350);
        setLocationRelativeTo(owner);
    }

    private void initUI() {
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Дата
        form.add(new JLabel("Дата (дд.мм.гггг):"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        dateField = new JTextField();
        form.add(dateField, gbc);

        // Класс
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Класс:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        classNameField = new JTextField();
        form.add(classNameField, gbc);

        // Тема
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Тема:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        topicField = new JTextField();
        form.add(topicField, gbc);

        // Содержание
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Содержание:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        contentArea = new JTextArea(3, 20);
        form.add(new JScrollPane(contentArea), gbc);

        // Кол-во участников
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Кол-во участников:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        participantsCountField = new JTextField();
        form.add(participantsCountField, gbc);

        // Результат
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        form.add(new JLabel("Результат:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        resultArea = new JTextArea(3, 20);
        form.add(new JScrollPane(resultArea), gbc);

        add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton saveButton = new JButton("Сохранить");
        JButton cancelButton = new JButton("Отмена");

        saveButton.addActionListener(e -> onSave());
        cancelButton.addActionListener(e -> dispose());

        buttons.add(saveButton);
        buttons.add(cancelButton);
        add(buttons, BorderLayout.SOUTH);

        if (existingActivity != null) {
            fillFields();
        }
    }

    private void fillFields() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        dateField.setText(sdf.format(existingActivity.getDate()));
        classNameField.setText(existingActivity.getClassName());
        topicField.setText(existingActivity.getTopic());
        contentArea.setText(existingActivity.getContent());
        participantsCountField.setText(String.valueOf(existingActivity.getParticipantsCount()));
        resultArea.setText(existingActivity.getResult());
    }

    private void onSave() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
            Date date = new Date(sdf.parse(dateField.getText().trim()).getTime());
            String className = classNameField.getText().trim();
            String topic = topicField.getText().trim();
            String content = contentArea.getText().trim();
            int participants = Integer.parseInt(participantsCountField.getText().trim());
            String result = resultArea.getText().trim();

            if (existingActivity == null) {
                PreventiveActivity newActivity = new PreventiveActivity(
                        0, journal.getId(), date, className, topic, content, participants, result
                );
                service.addPreventiveActivity(newActivity);
            } else {
                existingActivity.setDate(date);
                existingActivity.setClassName(className);
                existingActivity.setTopic(topic);
                existingActivity.setContent(content);
                existingActivity.setParticipantsCount(participants);
                existingActivity.setResult(result);
                service.updatePreventiveActivity(existingActivity);
            }

            saved = true;
            dispose();
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Неверный формат даты. Используйте дд.мм.гггг.",
                    "Ошибка", JOptionPane.WARNING_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Кол-во участников должно быть числом.",
                    "Ошибка", JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ошибка сохранения: " + ex.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSaved() {
        return saved;
    }
}