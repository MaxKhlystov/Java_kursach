package ui.dialogs;

import model.Journal;
import service.JournalService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class AddJournalDialog extends JDialog {
    private final JTextField nameField = new JTextField(20);
    private final JComboBox<String> typeComboBox = new JComboBox<>(new String[]{
            "Консультации", "Учёт индивидуальной и групповой работы", "Учёт соц-педагогической диагностики", "Профилактическая деятельность"
    });

    private final JournalService journalService;

    private static final Map<String, String> typeMap = new HashMap<>();

    static {
        typeMap.put("Консультации", "consultation");
        typeMap.put("Учёт индивидуальной и групповой работы", "correctionWork");
        typeMap.put("Учёт соц-педагогической диагностики", "diagnostic");
        typeMap.put("Профилактическая деятельность", "preventive");
    }

    public AddJournalDialog(JFrame parent, JournalService journalService) {
        super(parent, "Создание нового журнала", true);
        this.journalService = journalService;

        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        inputPanel.add(new JLabel("Название журнала:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Тип журнала:"));
        inputPanel.add(typeComboBox);

        JButton createButton = new JButton("Создать");
        createButton.addActionListener(e -> createJournal());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(createButton);

        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(parent);
    }

    private void createJournal() {
        String name = nameField.getText().trim();
        String type = (String) typeComboBox.getSelectedItem();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Введите название журнала.", "Ошибка", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Journal journal = new Journal(name, type);
            journalService.addJournal(journal);
            dispose();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Ошибка при создании журнала: " + ex.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
