package ui;

import model.Journal;
import service.JournalService;
import ui.panels.*;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

public class JournalPanel extends JPanel {
    private final JTabbedPane tabbedPane;

    public JournalPanel(JournalService service, Consumer<String> onTabChanged) {
        setLayout(new BorderLayout());

        tabbedPane = new JTabbedPane();

        //tabbedPane.addTab("Ученики", new StudentPanel(service));
        //tabbedPane.addTab("Консультации", new ConsultationPanel(service));
        //tabbedPane.addTab("Учёт индивидуальной и групповой работы", new CorrectionWorkPanel(service, journal));
        //tabbedPane.addTab("Учёт соц-педагогической диагностики", new DiagnosticPanel(service));
        //tabbedPane.addTab("Профилактическая деятельность", new PreventivePanel(service));

        tabbedPane.addChangeListener(e -> {
            String title = tabbedPane.getTitleAt(tabbedPane.getSelectedIndex());
            onTabChanged.accept(title);
        });

        add(tabbedPane, BorderLayout.CENTER);
    }
}
