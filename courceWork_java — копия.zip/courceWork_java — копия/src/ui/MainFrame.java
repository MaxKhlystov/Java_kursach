package ui;

import model.Journal;
import service.JournalService;
import ui.panels.JournalListPanel;
import ui.panels.*;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private final JournalService journalService;
    private final JPanel rightPanel = new JPanel(new BorderLayout());

    public MainFrame(JournalService journalService) {
        this.journalService = journalService;
        setTitle("Журналы социального педагога");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);

        JournalListPanel journalListPanel = new JournalListPanel(journalService, this::onJournalSelected);
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, journalListPanel, rightPanel);
        splitPane.setDividerLocation(300);
        add(splitPane);
    }

    private void onJournalSelected(Journal journal) {
        rightPanel.removeAll();

        JPanel content;
        switch (journal.getType()) {
            case "Ученики":
                content = new StudentPanel(journalService); // без journal
                break;
            case "Консультации":
                content = new ConsultationPanel(journalService, journal);
                break;
            case "Учёт индивидуальной и групповой работы":
                content = new CorrectionWorkPanel(journalService, journal);
                break;
            case "Учёт соц-педагогической диагностики":
                content = new DiagnosticPanel(journalService, journal);
                break;
            case "Профилактическая деятельность":
                content = new PreventivePanel(journalService, journal);
                break;
            default:
                content = new JPanel();
                content.add(new JLabel("Неизвестный тип журнала: " + journal.getType()));
        }

        rightPanel.add(content, BorderLayout.CENTER);
        rightPanel.revalidate();
        rightPanel.repaint();
    }
}
