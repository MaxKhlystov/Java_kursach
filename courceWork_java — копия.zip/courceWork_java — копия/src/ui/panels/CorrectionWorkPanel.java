package ui.panels;

import ui.dialogs.CorrectionWorkDialog;
import model.Journal;
import model.CorrectionWork;
import service.JournalService;
import ui.models.CorrectionWorkTableModel;
import ui.models.TableUtils;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CorrectionWorkPanel extends JPanel {
    private final CorrectionWorkTableModel tableModel = new CorrectionWorkTableModel();
    private final JTable table = new JTable(tableModel);
    private final JournalService service;
    private final Journal journal;

    public CorrectionWorkPanel(JournalService service, Journal journal) {
        this.service = service;
        this.journal = journal;
        setLayout(new BorderLayout());

        TableUtils.applyAutoResize(table);

        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton addButton = new JButton("Добавить");
        JButton editButton = new JButton("Редактировать");
        JButton deleteButton = new JButton("Удалить");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> {
            CorrectionWorkDialog dialog = new CorrectionWorkDialog(SwingUtilities.getWindowAncestor(this), service, journal, null);
            dialog.setVisible(true);
            loadData();
        });

        editButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                CorrectionWork selected = tableModel.getCorrectionWorkAt(row);
                CorrectionWorkDialog dialog = new CorrectionWorkDialog(SwingUtilities.getWindowAncestor(this), service, journal, selected);
                dialog.setVisible(true);
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, "Выберите запись для редактирования.");
            }
        });

        deleteButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                int confirm = JOptionPane.showConfirmDialog(this, "Удалить выбранную запись?", "Подтверждение", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    CorrectionWork selected = tableModel.getCorrectionWorkAt(row);
                    service.deleteCorrectionWork(selected.getId());
                    loadData();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Выберите запись для удаления.");
            }
        });

        loadData();
    }

    private void loadData() {
        try {
            List<CorrectionWork> all = service.getAllCorrectionWorks();
            List<CorrectionWork> filtered = all.stream()
                    .filter(cw -> cw.getJournalId() == journal.getId())
                    .toList();
            tableModel.setCorrectionWorks(filtered);

            TableUtils.resizeRowHeights(table);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ошибка загрузки коррекционных работ: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
