package ui.panels;

import ui.models.TableUtils;
import model.Consultation;
import model.Journal;
import service.JournalService;
import ui.dialogs.ConsultationDialog;
import ui.models.ConsultationTableModel;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ConsultationPanel extends JPanel {
    private final ConsultationTableModel tableModel = new ConsultationTableModel();
    private final JTable table = new JTable(tableModel);
    private final JournalService service;
    private final Journal journal;

    public ConsultationPanel(JournalService service, Journal journal) {
        this.service = service;
        this.journal = journal;
        setLayout(new BorderLayout());

        TableUtils.applyAutoResize(table);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);

        loadData();
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JButton addButton = new JButton("Добавить");
        JButton editButton = new JButton("Редактировать");
        JButton deleteButton = new JButton("Удалить");

        addButton.addActionListener(e -> onAdd());
        editButton.addActionListener(e -> onEdit());
        deleteButton.addActionListener(e -> onDelete());

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        return buttonPanel;
    }

    private void loadData() {
        try {
            List<Consultation> consultations = service.getConsultationsByJournalId(journal.getId());
            tableModel.setConsultations(consultations);

            TableUtils.resizeRowHeights(table);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ошибка загрузки консультаций: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onAdd() {
        ConsultationDialog dialog = new ConsultationDialog(SwingUtilities.getWindowAncestor(this), service, journal, null);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            loadData();
        }
    }

    private void onEdit() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Выберите консультацию для редактирования.");
            return;
        }
        Consultation consultation = tableModel.getConsultationAt(row);
        ConsultationDialog dialog = new ConsultationDialog(SwingUtilities.getWindowAncestor(this), service, journal, consultation);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            loadData();
        }
    }

    private void onDelete() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Выберите консультацию для удаления.");
            return;
        }
        Consultation consultation = tableModel.getConsultationAt(row);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Удалить выбранную консультацию?",
                "Подтверждение", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                service.deleteConsultation(consultation.getId());
                loadData();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Ошибка удаления: " + e.getMessage(),
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
