package ui.panels;

import model.PreventiveActivity;
import model.Journal;
import service.JournalService;
import ui.models.PreventiveTableModel;
import ui.dialogs.PreventiveDialog;
import ui.models.TableUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class PreventivePanel extends JPanel {
    private final JournalService service;
    private final Journal currentJournal;
    private final JTable table;
    private final PreventiveTableModel tableModel;

    public PreventivePanel(JournalService service, Journal currentJournal) {
        this.service = service;
        this.currentJournal = currentJournal;

        setLayout(new BorderLayout());

        tableModel = new PreventiveTableModel();
        table = new JTable(tableModel);

        TableUtils.applyAutoResize(table);
        TableUtils.resizeRowHeights(table);

        refreshTable();

        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton addButton = new JButton("Добавить");
        addButton.addActionListener(this::onAdd);

        JButton editButton = new JButton("Редактировать");
        editButton.addActionListener(this::onEdit);

        JButton deleteButton = new JButton("Удалить");
        deleteButton.addActionListener(this::onDelete);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void refreshTable() {
        List<PreventiveActivity> activities = service.getPreventiveActivitiesByJournalId(currentJournal.getId());
        tableModel.setData(activities);
        TableUtils.resizeRowHeights(table);
    }

    private void onAdd(ActionEvent e) {
        PreventiveDialog dialog = new PreventiveDialog(SwingUtilities.getWindowAncestor(this), service, currentJournal, null);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            refreshTable();
        }
    }

    private void onEdit(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            PreventiveActivity selected = tableModel.getActivityAt(selectedRow);
            PreventiveDialog dialog = new PreventiveDialog(SwingUtilities.getWindowAncestor(this), service, currentJournal, selected);
            dialog.setVisible(true);
            if (dialog.isSaved()) {
                refreshTable();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Выберите запись для редактирования", "Предупреждение", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void onDelete(ActionEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            PreventiveActivity selected = tableModel.getActivityAt(selectedRow);
            int confirm = JOptionPane.showConfirmDialog(this, "Удалить запись?", "Подтверждение", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                service.deletePreventiveActivity(selected.getId());
                refreshTable();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Выберите запись для удаления", "Предупреждение", JOptionPane.WARNING_MESSAGE);
        }
    }
}
