package ui.panels;

import model.Student;
import service.JournalService;
import ui.dialogs.AddStudentDialog;
import ui.models.StudentTableModel;
import ui.models.TableUtils;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class StudentPanel extends JPanel {
    private final StudentTableModel tableModel = new StudentTableModel();
    private final JTable table = new JTable(tableModel);
    private final JournalService service;

    public StudentPanel(JournalService service) {
        this.service = service;
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addButton = new JButton("Добавить");
        JButton editButton = new JButton("Редактировать");
        JButton deleteButton = new JButton("Удалить");

        addButton.addActionListener(e -> onAdd());
        editButton.addActionListener(e -> onEdit());
        deleteButton.addActionListener(e -> onDelete());

        topPanel.add(addButton);
        topPanel.add(editButton);
        topPanel.add(deleteButton);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        TableUtils.applyAutoResize(table);
        TableUtils.resizeRowHeights(table);

        loadData();
    }

    private void loadData() {
        try {
            List<Student> students = service.getAllStudents();
            tableModel.setStudents(students);
            TableUtils.resizeRowHeights(table);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Не удалось загрузить список учеников:\n" + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onAdd() {
        AddStudentDialog dialog = new AddStudentDialog((JFrame) SwingUtilities.getWindowAncestor(this));
        dialog.setVisible(true);
        if (dialog.isOkPressed()) {
            try {
                service.addStudent(dialog.getStudent());
                loadData();
            } catch (Exception ex) {
                showError("Не удалось добавить ученика", ex);
            }
        }
    }

    private void onEdit() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите ученика для редактирования", "Ошибка", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Student selected = tableModel.getStudentAt(selectedRow);
        AddStudentDialog dialog = new AddStudentDialog((JFrame) SwingUtilities.getWindowAncestor(this), selected);
        dialog.setVisible(true);
        if (dialog.isOkPressed()) {
            try {
                service.updateStudent(dialog.getStudent());
                loadData();
            } catch (Exception ex) {
                showError("Не удалось обновить ученика", ex);
            }
        }
    }

    private void onDelete() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите ученика для удаления", "Ошибка", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Student selected = tableModel.getStudentAt(selectedRow);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Удалить ученика: " + selected.getFullName() + "?",
                "Подтверждение удаления",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                service.deleteStudent(selected.getId());
                loadData();
            } catch (Exception ex) {
                showError("Не удалось удалить ученика", ex);
            }
        }
    }

    private void showError(String message, Exception ex) {
        JOptionPane.showMessageDialog(this,
                message + ":\n" + ex.getMessage(),
                "Ошибка", JOptionPane.ERROR_MESSAGE);
    }
}
