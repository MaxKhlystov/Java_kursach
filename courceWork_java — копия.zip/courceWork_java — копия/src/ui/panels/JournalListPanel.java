package ui.panels;

import model.Journal;
import service.JournalService;
import ui.dialogs.AddJournalDialog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.function.Consumer;

public class JournalListPanel extends JPanel {
    private final JournalService journalService;
    private final Consumer<Journal> journalSelectedCallback;

    private final DefaultListModel<Journal> listModel = new DefaultListModel<>();
    private final JList<Journal> journalList = new JList<>(listModel);
    private final JComboBox<String> filterComboBox;

    private static final String[] TYPES = {
            "Все типы", "Консультации", "Учёт индивидуальной и групповой работы",
            "Учёт соц-педагогической диагностики", "Профилактическая деятельность"
    };

    public JournalListPanel(JournalService journalService, Consumer<Journal> journalSelectedCallback) {
        this.journalService = journalService;
        this.journalSelectedCallback = journalSelectedCallback;

        setLayout(new BorderLayout());

        // панель верзних кнопок
        JPanel topButtonPanel = new JPanel();
        topButtonPanel.setLayout(new GridLayout(3, 1, 5, 5));

        JButton studentButton = new JButton("📋 Список учеников");
        studentButton.setFont(studentButton.getFont().deriveFont(Font.BOLD, 16f));
        studentButton.setBackground(new Color(70, 130, 180));
        studentButton.setForeground(Color.WHITE);
        studentButton.setFocusPainted(false);
        studentButton.setPreferredSize(new Dimension(300, 40));
        studentButton.addActionListener(e -> {
            Journal dummy = new Journal(-1, "Список учеников", "Ученики");
            journalSelectedCallback.accept(dummy);
        });

        JButton addJournalButton = new JButton("➕ Создать журнал");
        addJournalButton.setFont(addJournalButton.getFont().deriveFont(Font.BOLD, 16f));
        addJournalButton.setBackground(new Color(34, 139, 34));
        addJournalButton.setForeground(Color.WHITE);
        addJournalButton.setFocusPainted(false);
        addJournalButton.setPreferredSize(new Dimension(300, 40));
        addJournalButton.addActionListener(e -> {
            AddJournalDialog dialog = new AddJournalDialog((JFrame) SwingUtilities.getWindowAncestor(this), journalService);
            dialog.setVisible(true);
            loadJournals();
        });

        JButton deleteJournalButton = new JButton("🗑️ Удалить журнал");
        deleteJournalButton.setFont(deleteJournalButton.getFont().deriveFont(Font.BOLD, 16f));
        deleteJournalButton.setBackground(new Color(178, 34, 34));
        deleteJournalButton.setForeground(Color.WHITE);
        deleteJournalButton.setFocusPainted(false);
        deleteJournalButton.setPreferredSize(new Dimension(300, 40));
        deleteJournalButton.addActionListener(e -> deleteSelectedJournal());

        topButtonPanel.add(studentButton);
        topButtonPanel.add(addJournalButton);
        topButtonPanel.add(deleteJournalButton);

        filterComboBox = new JComboBox<>(TYPES);
        filterComboBox.addActionListener(e -> loadJournals());

        journalList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        journalList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                Journal selected = journalList.getSelectedValue();
                if (selected != null) {
                    journalSelectedCallback.accept(selected);
                }
            }
        });

        JPopupMenu popupMenu = new JPopupMenu();

        JMenuItem renameItem = new JMenuItem("Переименовать журнал");
        renameItem.addActionListener(e -> renameSelectedJournal());
        popupMenu.add(renameItem);

        JMenuItem deleteItem = new JMenuItem("Удалить журнал");
        deleteItem.addActionListener(e -> deleteSelectedJournal());
        popupMenu.add(deleteItem);

        journalList.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    int index = journalList.locationToIndex(e.getPoint());
                    if (index != -1) {
                        journalList.setSelectedIndex(index);
                        popupMenu.show(journalList, e.getX(), e.getY());
                    }
                }
            }
        });

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(filterComboBox, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(journalList), BorderLayout.CENTER);

        add(topButtonPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);

        loadJournals();
    }

    public void loadJournals() {
        listModel.clear();
        String selectedType = (String) filterComboBox.getSelectedItem();

        try {
            List<Journal> journals;

            if (selectedType != null && !selectedType.equals("Все типы")) {
                journals = journalService.getJournalsByType(selectedType);
            } else {
                journals = journalService.getAllJournals();
            }

            for (Journal j : journals) {
                listModel.addElement(j);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Ошибка загрузки журналов: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedJournal() {
        Journal selected = journalList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Выберите журнал для удаления.", "Внимание", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int result = JOptionPane.showConfirmDialog(this,
                "Вы уверены, что хотите удалить журнал \"" + selected.getName() + "\"?",
                "Подтверждение удаления", JOptionPane.YES_NO_OPTION);

        if (result == JOptionPane.YES_OPTION) {
            try {
                journalService.deleteJournal(selected.getId());
                loadJournals();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Ошибка при удалении журнала: " + ex.getMessage(),
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void renameSelectedJournal() {
        Journal selected = journalList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Выберите журнал для переименования.", "Внимание", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String newName = JOptionPane.showInputDialog(this, "Введите новое название журнала:", selected.getName());
        if (newName != null && !newName.trim().isEmpty()) {
            selected.setName(newName.trim());
            try {
                journalService.updateJournal(selected);
                loadJournals();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Ошибка при переименовании журнала: " + ex.getMessage(),
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void setFilterType(String type) {
        if (type == null || type.isBlank()) {
            filterComboBox.setSelectedItem("Все типы");
        } else {
            filterComboBox.setSelectedItem(type);
        }
    }
}
