package ui.panels;

import model.DiagnosticRecord;
import model.Journal;
import service.JournalService;
import ui.dialogs.DiagnosticDialog;
import ui.models.DiagnosticTableModel;
import ui.models.TableUtils;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class DiagnosticPanel extends JPanel {
    private final JournalService service;
    private final DiagnosticTableModel tableModel = new DiagnosticTableModel();
    private final JTable table = new JTable(tableModel);
    private final Journal journal;

    public DiagnosticPanel(JournalService service, Journal journal) {
        this.service = service;
        this.journal = journal;

        setLayout(new BorderLayout());

        add(new JScrollPane(table), BorderLayout.CENTER);

        TableUtils.applyAutoResize(table);
        TableUtils.resizeRowHeights(table);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton addButton = new JButton("Добавить");
        JButton editButton = new JButton("Редактировать");
        JButton deleteButton = new JButton("Удалить");

        addButton.addActionListener(e -> onAdd());
        editButton.addActionListener(e -> onEdit());
        deleteButton.addActionListener(e -> onDelete());

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        add(buttonPanel, BorderLayout.SOUTH);

        loadData();
    }

    private void loadData() {
        try {
            List<DiagnosticRecord> diagnostics = service.getDiagnosticRecordsByJournalId(journal.getId());
            tableModel.setRecords(diagnostics);
            TableUtils.resizeRowHeights(table);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ошибка загрузки диагностик: " + e.getMessage(),
                    "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onAdd() {
        DiagnosticDialog dialog = new DiagnosticDialog(SwingUtilities.getWindowAncestor(this), service, journal, null);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            service.addDiagnosticRecord(dialog.getRecord());
            loadData();
        }
    }

    private void onEdit() {
        int selected = table.getSelectedRow();
        if (selected == -1) {
            JOptionPane.showMessageDialog(this, "Выберите запись для редактирования.");
            return;
        }

        DiagnosticRecord record = tableModel.getRecordAt(selected);
        DiagnosticDialog dialog = new DiagnosticDialog(SwingUtilities.getWindowAncestor(this), service, journal, record);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            service.updateDiagnosticRecord(dialog.getRecord());
            loadData();
        }
    }

    private void onDelete() {
        int selected = table.getSelectedRow();
        if (selected == -1) {
            JOptionPane.showMessageDialog(this, "Выберите запись для удаления.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Удалить выбранную запись?", "Подтверждение", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            DiagnosticRecord record = tableModel.getRecordAt(selected);
            service.deleteDiagnosticRecord(record.getId());
            loadData();
        }
    }
}
