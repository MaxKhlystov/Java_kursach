package ui.models;

import model.DiagnosticRecord;
import javax.swing.table.AbstractTableModel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class DiagnosticTableModel extends AbstractTableModel {
    private final List<DiagnosticRecord> records;
    private final String[] columnNames = {"№", "Дата", "Форма проведения", "С кем проводится",
            "Количество", "Тематика", "Содержание и результат"};
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    public DiagnosticTableModel() {
        this.records = new ArrayList<>();
    }

    @Override
    public int getRowCount() {
        return records.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        DiagnosticRecord r = records.get(rowIndex);
        switch (columnIndex) {
            case 0: return rowIndex + 1;
            case 1: return dateFormat.format(r.getDate());
            case 2: return r.getForm();
            case 3: return r.getParticipants();
            case 4: return r.getParticipantsCount();
            case 5: return r.getTopic();
            case 6: return "Содержание: " + r.getContent() + "\n\n Результат: " + r.getResult();
            default: return null;
        }
    }

    public void setRecords(List<DiagnosticRecord> diagnosticRecords) {
        records.clear();
        records.addAll(diagnosticRecords);
        fireTableDataChanged();
    }

    public DiagnosticRecord getRecordAt(int row) {
        return records.get(row);
    }
}
