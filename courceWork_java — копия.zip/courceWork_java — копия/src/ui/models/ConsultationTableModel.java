package ui.models;

import model.Consultation;
import javax.swing.table.AbstractTableModel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class ConsultationTableModel extends AbstractTableModel {
    private final List<Consultation> consultations;
    private final String[] columnNames = {"№", "Дата", "ФИО", "Класс", "Причина обращения",
            "Краткое содержание", "Результат"};
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    public ConsultationTableModel() {
        this.consultations = new ArrayList<>();
    }

    @Override
    public int getRowCount() {
        return consultations.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Consultation c = consultations.get(rowIndex);
        switch (columnIndex) {
            case 0: return rowIndex + 1;
            case 1: return dateFormat.format(c.getDate());
            case 2: return c.getStudent().getFullName();
            case 3: return c.getStudent().getClassName();
            case 4: return c.getReason();
            case 5: return c.getContent();
            case 6: return c.getResult();
            default: return null;
        }
    }

    public Consultation getConsultationAt(int row) {
        return consultations.get(row);
    }

    public void setConsultations(List<Consultation> consultations) {
        this.consultations.clear();
        this.consultations.addAll(consultations);
        fireTableDataChanged();
    }
}