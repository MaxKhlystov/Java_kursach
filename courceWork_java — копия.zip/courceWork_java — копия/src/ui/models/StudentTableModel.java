package ui.models;

import model.Student;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class StudentTableModel extends AbstractTableModel {
    private final List<Student> students;
    private final String[] columnNames = {"№", "Фамилия", "Имя", "Отчество", "Класс"};

    public StudentTableModel() {
        this.students = new ArrayList<>();
    }

    @Override
    public int getRowCount() {
        return students.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Student student = students.get(rowIndex);
        switch (columnIndex) {
            case 0: return rowIndex + 1; // порядковый номер
            case 1: return student.getLastName();
            case 2: return student.getFirstName();
            case 3: return student.getMiddleName();
            case 4: return student.getClassName();
            default: return null;
        }
    }

    public void setStudents(List<Student> students) {
        this.students.clear();
        this.students.addAll(students);
        fireTableDataChanged();
    }

    public Student getStudentAt(int row) {
        return students.get(row);
    }
}