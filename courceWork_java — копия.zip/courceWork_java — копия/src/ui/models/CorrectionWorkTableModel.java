package ui.models;

import model.CorrectionWork;
import javax.swing.table.AbstractTableModel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class CorrectionWorkTableModel extends AbstractTableModel {
    private final List<CorrectionWork> works;
    private final String[] columnNames = {"№", "Дата/Вид", "ФИО ребенка/родителя", "Класс",
            "Тематика", "Решение", "Рекомендации", "Результат"};
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    public CorrectionWorkTableModel() {
        this.works = new ArrayList<>();
    }

    @Override
    public int getRowCount() {
        return works.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        CorrectionWork c = works.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> rowIndex + 1;
            case 1 -> dateFormat.format(c.getDate()) + " (" + (c.getType().equals("INDIVIDUAL") ? "и" : "г") + ")";
            case 2 -> "Ученик: " + c.getStudent().getFullName() + " Родитель: " + c.getParentName();
            case 3 -> c.getClassName();
            case 4 -> c.getTopic();
            case 5 -> c.getSolution();
            case 6 -> c.getRecommendations();
            case 7 -> c.getResult();
            default -> null;
        };
    }

    public void setCorrectionWorks(List<CorrectionWork> works) {
        this.works.clear();
        this.works.addAll(works);
        fireTableDataChanged();
    }

    public CorrectionWork getCorrectionWorkAt(int row) {
        return works.get(row);
    }
}