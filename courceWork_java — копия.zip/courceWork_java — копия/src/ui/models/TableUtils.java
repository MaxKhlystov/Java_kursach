package ui.models;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class TableUtils {

    public static void applyAutoResize(JTable table) {
        table.setDefaultRenderer(Object.class, new TextAreaRenderer());
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        resizeRowHeights(table);
    }

    public static void resizeRowHeights(JTable table) {
        for (int row = 0; row < table.getRowCount(); row++) {
            int maxHeight = table.getRowHeight();

            for (int column = 0; column < table.getColumnCount(); column++) {
                TableCellRenderer renderer = table.getCellRenderer(row, column);
                Component comp = table.prepareRenderer(renderer, row, column);

                if (comp != null) {
                    int height = comp.getPreferredSize().height;
                    maxHeight = Math.max(height, maxHeight);
                }
            }

            if (table.getRowHeight(row) != maxHeight) {
                table.setRowHeight(row, maxHeight);
            }
        }
    }

    public static class TextAreaRenderer extends JTextArea implements TableCellRenderer {

        public TextAreaRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            setText(value == null ? "" : value.toString());

            if (isSelected) {
                setForeground(table.getSelectionForeground());
                setBackground(table.getSelectionBackground());
            } else {
                setForeground(table.getForeground());
                setBackground(table.getBackground());
            }

            setFont(table.getFont());
            setBorder(null);

            int columnWidth = table.getColumnModel().getColumn(column).getWidth();
            setSize(new Dimension(columnWidth, Integer.MAX_VALUE));

            return this;
        }
    }
}
