package model;

import java.sql.Date;

public class Consultation {
    private int id;
    private int journalId;
    private Date date;
    private Student student;
    private String reason;
    private String content;
    private String result;

    public Consultation(int id, int journalId, Date date, Student student,
                        String reason, String content, String result) {
        this.id = id;
        this.journalId = journalId;
        this.date = date;
        this.student = student;
        this.reason = reason;
        this.content = content;
        this.result = result;
    }

    public int getId() { return id; }
    public int getJournalId() { return journalId; }
    public Date getDate() { return date; }
    public Student getStudent() { return student; }
    public String getReason() { return reason; }
    public String getContent() { return content; }
    public String getResult() { return result; }

    public void setId(int id) { this.id = id; }
    public void setJournalId(int journalId) { this.journalId = journalId; }
    public void setDate(Date date) { this.date = date; }
    public void setStudent(Student student) { this.student = student; }
    public void setReason(String reason) { this.reason = reason; }
    public void setContent(String content) { this.content = content; }
    public void setResult(String result) { this.result = result; }

    @Override
    public String toString() {
        return date + " — " + student;
    }
}
