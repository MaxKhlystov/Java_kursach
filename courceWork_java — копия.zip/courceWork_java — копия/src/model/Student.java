package model;

public class Student {
    private int id;
    private String lastName;
    private String firstName;
    private String middleName;
    private String className;

    public Student(int id, String lastName, String firstName, String middleName, String className) {
        this.id = id;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
        this.className = className;
    }

    public Student() {
        this(0, "", "", "", "");
    }

    public Student(String lastName, String firstName, String middleName, String className) {
        this(0, lastName, firstName, middleName, className);
    }

    // Геттеры и сеттеры
    public int getId() {
        return id;
    }

    public String getLastName() {
        return lastName;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getMiddleName() {
        return middleName;
    }
    public String getClassName() {
        return className;
    }

    public void setId(int id) {
        this.id = id;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    public void setClassName(String className) {
        this.className = className;
    }

    public String getFullName() {
        return lastName + " " + firstName + " " + middleName;
    }
}
