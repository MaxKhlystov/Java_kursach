package model;

import java.sql.Date;

public class CorrectionWork {
    private int id;
    private Date date;
    private String type;
    private Student student;
    private String parentName;
    private String className;
    private String topic;
    private String solution;
    private String recommendations;
    private String result;
    private int journalId;

    public CorrectionWork(int id, Date date, String type, Student student, String parentName,
                          String className, String topic, String solution,
                          String recommendations, String result, int journalId) {
        this.id = id;
        this.date = date;
        this.type = type;
        this.student = student;
        this.parentName = parentName;
        this.className = className;
        this.topic = topic;
        this.solution = solution;
        this.recommendations = recommendations;
        this.result = result;
        this.journalId = journalId;
    }

    // Геттеры
    public int getId() { return id; }
    public Date getDate() { return date; }
    public String getType() { return type; }
    public Student getStudent() { return student; }
    public String getParentName() { return parentName; }
    public String getClassName() { return className; }
    public String getTopic() { return topic; }
    public String getSolution() { return solution; }
    public String getRecommendations() { return recommendations; }
    public String getResult() { return result; }
    public int getJournalId() { return journalId; }

    // Сеттеры
    public void setId(int id) { this.id = id; }
    public void setDate(Date date) { this.date = date; }
    public void setType(String type) { this.type = type; }
    public void setStudent(Student student) { this.student = student; }
    public void setParentName(String parentName) { this.parentName = parentName; }
    public void setClassName(String className) { this.className = className; }
    public void setTopic(String topic) { this.topic = topic; }
    public void setSolution(String solution) { this.solution = solution; }
    public void setRecommendations(String recommendations) { this.recommendations = recommendations; }
    public void setResult(String result) { this.result = result; }
    public void setJournalId(int journalId) { this.journalId = journalId; }
}
