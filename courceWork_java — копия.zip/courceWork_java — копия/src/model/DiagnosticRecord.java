package model;

import java.sql.Date;

public class DiagnosticRecord {
    private int id;
    private Date date;
    private String form;
    private String participants;
    private int participantsCount;
    private String topic;
    private String content;
    private String result;
    private int journalId;

    public DiagnosticRecord(int id, Date date, String form, String participants, int participantsCount,
                            String topic, String content, String result, int journalId) {
        this.id = id;
        this.date = date;
        this.form = form;
        this.participants = participants;
        this.participantsCount = participantsCount;
        this.topic = topic;
        this.content = content;
        this.result = result;
        this.journalId = journalId;
    }

    // Геттеры и сеттеры
    public int getId() { return id; }
    public Date getDate() { return date; }
    public String getForm() { return form; }
    public String getParticipants() { return participants; }
    public int getParticipantsCount() { return participantsCount; }
    public String getTopic() { return topic; }
    public String getContent() { return content; }
    public String getResult() { return result; }
    public int getJournalId() { return journalId; }

    public void setId(int id) { this.id = id; }
    public void setDate(Date date) { this.date = date; }
    public void setForm(String form) { this.form = form; }
    public void setParticipants(String participants) { this.participants = participants; }
    public void setParticipantsCount(int participantsCount) { this.participantsCount = participantsCount; }
    public void setTopic(String topic) { this.topic = topic; }
    public void setContent(String content) { this.content = content; }
    public void setResult(String result) { this.result = result; }
    public void setJournalId(int journalId) { this.journalId = journalId; }
}
