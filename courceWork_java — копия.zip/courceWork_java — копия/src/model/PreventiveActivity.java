package model;

import java.sql.Date;

public class PreventiveActivity {
    private int id;
    private Date date;
    private String className;
    private String topic;
    private String content;
    private int participantsCount;
    private String result;
    private int journalId;

    public int getJournalId() {
        return journalId;
    }

    public void setJournalId(int journalId) {
        this.journalId = journalId;
    }

    public PreventiveActivity(int id, int journalId, Date date, String className,
                              String topic, String content, int participantsCount, String result) {
        this.id = id;
        this.journalId = journalId;
        this.date = date;
        this.className = className;
        this.topic = topic;
        this.content = content;
        this.participantsCount = participantsCount;
        this.result = result;
    }


    // Геттеры и сеттеры
    public int getId() { return id; }
    public Date getDate() { return date; }
    public String getClassName() { return className; }
    public String getTopic() { return topic; }
    public String getContent() { return content; }
    public int getParticipantsCount() { return participantsCount; }
    public String getResult() { return result; }

    public void setId(int id) { this.id = id; }
    public void setDate(Date date) { this.date = date; }
    public void setClassName(String className) { this.className = className; }
    public void setTopic(String topic) { this.topic = topic; }
    public void setContent(String content) { this.content = content; }
    public void setParticipantsCount(int participantsCount) { this.participantsCount = participantsCount; }
    public void setResult(String result) { this.result = result; }
}