package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static final String URL = "jdbc:postgresql://localhost:5432/journals_db";
    private static final String USER = "postgres";
    private static final String PASSWORD = "556";
    private Connection connection;

    public DatabaseConnection() throws SQLException {
        this.connection = DriverManager.getConnection(URL, USER, PASSWORD);
        initializeDatabase();
    }

    public Connection getConnection() {
        return connection;
    }

    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    private void initializeDatabase() throws SQLException {
        try (Statement stmt = connection.createStatement()) {

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS journals (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    type VARCHAR(50) NOT NULL CHECK (type IN (
                        'Консультации', 'Учёт индивидуальной и групповой работы', 'Учёт соц-педагогической диагностики', 'Профилактическая деятельность'
                    )),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS students (
                    id SERIAL PRIMARY KEY,
                    last_name VARCHAR(100) NOT NULL,
                    first_name VARCHAR(100) NOT NULL,
                    middle_name VARCHAR(100),
                    class_name VARCHAR(20) NOT NULL
                );
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS consultations (
                    id SERIAL PRIMARY KEY,
                    date DATE NOT NULL,
                    student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
                    reason TEXT NOT NULL,
                    content TEXT NOT NULL,
                    result TEXT,
                    journal_id INTEGER REFERENCES journals(id) ON DELETE CASCADE
                );
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS correction_work (
                    id SERIAL PRIMARY KEY,
                    date DATE NOT NULL,
                    type VARCHAR(255) NOT NULL,
                    student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
                    parent_name VARCHAR(255),
                    class_name VARCHAR(255),
                    topic TEXT,
                    solution TEXT,
                    recommendations TEXT,
                    result TEXT,
                    journal_id INTEGER REFERENCES journals(id) ON DELETE CASCADE
                );
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS diagnostics (
                    id SERIAL PRIMARY KEY,
                    date DATE NOT NULL,
                    form VARCHAR(100) NOT NULL,
                    participants VARCHAR(200) NOT NULL,
                    participants_count INTEGER NOT NULL,
                    topic TEXT NOT NULL,
                    content TEXT NOT NULL,
                    result TEXT NOT NULL,
                    journal_id INTEGER REFERENCES journals(id) ON DELETE CASCADE
                );
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS preventive_activities (
                    id SERIAL PRIMARY KEY,
                    date DATE NOT NULL,
                    class_name VARCHAR(50) NOT NULL,
                    topic TEXT NOT NULL,
                    content TEXT NOT NULL,
                    participants_count INTEGER NOT NULL,
                    result TEXT,
                    journal_id INTEGER REFERENCES journals(id) ON DELETE CASCADE
                );
            """);

            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    username VARCHAR(50) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    role VARCHAR(20) DEFAULT 'user'
                );
            """);
        }
    }
}
