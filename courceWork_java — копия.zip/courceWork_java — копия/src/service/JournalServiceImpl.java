package service;

import dao.*;
import model.*;

import java.util.List;
import java.sql.Date;
import java.sql.SQLException;

public class JournalServiceImpl implements JournalService {

    private final StudentDAO studentDAO;
    private final ConsultationDAO consultationDAO;
    private final PreventiveActivityDAO preventiveActivityDAO;
    private final DiagnosticRecordDAO diagnosticRecordDAO;
    private final CorrectionWorkDAO correctionWorkDAO;
    private final JournalDAO journalDAO;

    public JournalServiceImpl(
            StudentDAO studentDAO,
            ConsultationDAO consultationDAO,
            PreventiveActivityDAO preventiveActivityDAO,
            DiagnosticRecordDAO diagnosticRecordDAO,
            CorrectionWorkDAO correctionWorkDAO,
            JournalDAO journalDAO
    ) {
        this.studentDAO = studentDAO;
        this.consultationDAO = consultationDAO;
        this.preventiveActivityDAO = preventiveActivityDAO;
        this.diagnosticRecordDAO = diagnosticRecordDAO;
        this.correctionWorkDAO = correctionWorkDAO;
        this.journalDAO = journalDAO;
    }

    // Student
    @Override
    public List<Student> getAllStudents() {
        return studentDAO.getAllStudents();
    }

    @Override
    public void addStudent(Student student) {
        studentDAO.addStudent(student);
    }

    @Override
    public void updateStudent(Student student) {
        studentDAO.updateStudent(student);
    }

    @Override
    public void deleteStudent(int studentId) {
        studentDAO.deleteStudent(studentId);
    }

    @Override
    public Student getStudentById(int studentId) {
        return studentDAO.getStudentById(studentId);
    }

    @Override
    public List<Student> findStudents(String query) {
        return studentDAO.findStudents(query);
    }

    // ЖУРНАЛЫ
    @Override
    public void addJournal(Journal journal) throws SQLException {
        journalDAO.addJournal(journal);
    }

    @Override
    public void deleteJournal(int journalId) throws SQLException {
        journalDAO.deleteJournal(journalId);
    }

    @Override
    public List<Journal> getAllJournals() throws SQLException {
        return journalDAO.getAllJournals();
    }

    @Override
    public List<Journal> getJournalsByType(String type) throws SQLException {
        return journalDAO.getJournalsByType(type);
    }

    @Override
    public Journal getJournalById(int id) throws SQLException {
        return journalDAO.getJournalById(id);
    }

    @Override
    public void updateJournal(Journal journal) throws SQLException {
        journalDAO.updateJournal(journal);
    }

    // сonsultation
    @Override
    public List<Consultation> getAllConsultations() {
        return consultationDAO.getAllConsultations();
    }

    @Override
    public void addConsultation(Consultation consultation) {
        consultationDAO.addConsultation(consultation);
    }

    @Override
    public void updateConsultation(Consultation consultation) {
        consultationDAO.updateConsultation(consultation);
    }

    @Override
    public void deleteConsultation(int consultationId) {
        consultationDAO.deleteConsultation(consultationId);
    }

    @Override
    public Consultation getConsultationById(int consultationId) {
        return consultationDAO.getConsultationById(consultationId);
    }

    @Override
    public List<Consultation> getConsultationsByStudentId(int studentId) {
        return consultationDAO.getByStudentId(studentId);
    }

    @Override
    public List<Consultation> getConsultationsByDate(java.sql.Date date) {
        return consultationDAO.getByDate(date);
    }

    @Override
    public List<Consultation> getConsultationsByJournalId(int journalId) {
        return consultationDAO.getByJournalId(journalId);
    }

    // CorrectionWork
    @Override
    public List<CorrectionWork> getAllCorrectionWorks() {
        return correctionWorkDAO.getAllCorrectionWorks();
    }

    @Override
    public void addCorrectionWork(CorrectionWork correctionWork) {
        correctionWorkDAO.addCorrectionWork(correctionWork);
    }

    @Override
    public void updateCorrectionWork(CorrectionWork correctionWork) {
        correctionWorkDAO.updateCorrectionWork(correctionWork);
    }

    @Override
    public void deleteCorrectionWork(int id) {
        correctionWorkDAO.deleteCorrectionWork(id);
    }

    @Override
    public CorrectionWork getCorrectionWorkById(int id) {
        return correctionWorkDAO.getCorrectionWorkById(id);
    }

    @Override
    public List<CorrectionWork> getCorrectionWorksByStudentId(int studentId) {
        return correctionWorkDAO.getByStudentId(studentId);
    }

    @Override
    public List<DiagnosticRecord> getDiagnosticRecordsByJournalId(int journalId) throws SQLException {
        return diagnosticRecordDAO.getByJournalId(journalId);
    }


    // DiagnosticRecord
    @Override
    public List<DiagnosticRecord> getAllDiagnosticRecords() {
        return diagnosticRecordDAO.getAllDiagnosticRecords();
    }

    @Override
    public void addDiagnosticRecord(DiagnosticRecord record) {
        diagnosticRecordDAO.addDiagnosticRecord(record);
    }

    @Override
    public void updateDiagnosticRecord(DiagnosticRecord record) {
        diagnosticRecordDAO.updateDiagnosticRecord(record);
    }

    @Override
    public void deleteDiagnosticRecord(int id) {
        diagnosticRecordDAO.deleteDiagnosticRecord(id);
    }

    @Override
    public DiagnosticRecord getDiagnosticRecordById(int id) {
        return diagnosticRecordDAO.getDiagnosticRecordById(id);
    }

    @Override
    public List<DiagnosticRecord> getDiagnosticRecordsByStudentId(int studentId) {
        return diagnosticRecordDAO.getByStudentId(studentId);
    }

    @Override
    public List<DiagnosticRecord> getDiagnosticRecordsByDate(Date date) {
        return diagnosticRecordDAO.getByDate(date);
    }

    // PreventiveActivity
    @Override
    public List<PreventiveActivity> getAllPreventiveActivities() {
        try {
            return preventiveActivityDAO.getAllPreventiveActivities();
        } catch (SQLException e) {
            throw new RuntimeException("Ошибка при получении всех профилактических мероприятий", e);
        }
    }

    @Override
    public void addPreventiveActivity(PreventiveActivity activity) {
        try {
            preventiveActivityDAO.addPreventiveActivity(activity, activity.getJournalId());
        } catch (SQLException e) {
            throw new RuntimeException("Ошибка при добавлении профилактической активности", e);
        }
    }

    @Override
    public void updatePreventiveActivity(PreventiveActivity activity) {
        try {
            preventiveActivityDAO.updatePreventiveActivity(activity);
        } catch (SQLException e) {
            throw new RuntimeException("Ошибка при обновлении профилактической активности", e);
        }
    }

    @Override
    public void deletePreventiveActivity(int id) {
        try {
            preventiveActivityDAO.deletePreventiveActivity(id);
        } catch (SQLException e) {
            throw new RuntimeException("Ошибка при удалении профилактической активности", e);
        }
    }

    @Override
    public PreventiveActivity getPreventiveActivityById(int id) {
        try {
            return preventiveActivityDAO.getPreventiveActivityById(id);
        } catch (SQLException e) {
            throw new RuntimeException("Ошибка при получении профилактической активности по ID", e);
        }
    }

    @Override
    public List<PreventiveActivity> getPreventiveActivitiesByDate(Date date) {
        try {
            return preventiveActivityDAO.getByDate(new java.sql.Date(date.getTime()));
        } catch (SQLException e) {
            throw new RuntimeException("Ошибка при получении профилактических мероприятий по дате", e);
        }
    }

    @Override
    public List<PreventiveActivity> getPreventiveActivitiesByJournalId(long journalId) {
        try {
            return preventiveActivityDAO.getByJournalId(journalId);
        } catch (SQLException e) {
            throw new RuntimeException("Не удалось получить профилактические мероприятия по журналу", e);
        }
    }

}
