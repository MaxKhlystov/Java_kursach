package service;

import model.*;

import java.sql.Date;
import java.util.List;
import java.sql.SQLException;

public interface JournalService {
    // Ученики
    List<Student> getAllStudents();
    void addStudent(Student student);
    void updateStudent(Student student);
    void deleteStudent(int id);
    Student getStudentById(int id);
    List<Student> findStudents(String keyword);

    // ЖУРНАЛЫ
    void addJournal(Journal journal) throws SQLException;
    void deleteJournal(int journalId) throws SQLException;
    List<Journal> getAllJournals() throws SQLException;
    List<Journal> getJournalsByType(String type) throws SQLException;
    Journal getJournalById(int id) throws SQLException;
    void updateJournal(Journal journal) throws SQLException;

    // Consultations
    List<Consultation> getAllConsultations();
    void addConsultation(Consultation consultation);
    void updateConsultation(Consultation consultation);
    void deleteConsultation(int id);
    Consultation getConsultationById(int id);
    List<Consultation> getConsultationsByStudentId(int studentId);
    List<Consultation> getConsultationsByDate(Date date);
    List<Consultation> getConsultationsByJournalId(int journalId);

    // Correction Work
    List<CorrectionWork> getAllCorrectionWorks();
    void addCorrectionWork(CorrectionWork correctionWork);
    void updateCorrectionWork(CorrectionWork correctionWork);
    void deleteCorrectionWork(int id);
    CorrectionWork getCorrectionWorkById(int id);
    List<CorrectionWork> getCorrectionWorksByStudentId(int studentId);
    //List<CorrectionWork> getCorrectionWorksByDate(Date date);
    List<DiagnosticRecord> getDiagnosticRecordsByJournalId(int journalId) throws SQLException;

    // Diagnostic Records
    List<DiagnosticRecord> getAllDiagnosticRecords();
    void addDiagnosticRecord(DiagnosticRecord record);
    void updateDiagnosticRecord(DiagnosticRecord record);
    void deleteDiagnosticRecord(int id);
    DiagnosticRecord getDiagnosticRecordById(int id);
    List<DiagnosticRecord> getDiagnosticRecordsByStudentId(int studentId);
    List<DiagnosticRecord> getDiagnosticRecordsByDate(Date date);

    // Preventive Activities
    List<PreventiveActivity> getAllPreventiveActivities();
    void addPreventiveActivity(PreventiveActivity activity);
    void updatePreventiveActivity(PreventiveActivity activity);
    void deletePreventiveActivity(int id);
    PreventiveActivity getPreventiveActivityById(int id);
    //List<PreventiveActivity> getPreventiveActivitiesByStudentId(int studentId);
    List<PreventiveActivity> getPreventiveActivitiesByJournalId(long journalId);
    List<PreventiveActivity> getPreventiveActivitiesByDate(Date date);
}
